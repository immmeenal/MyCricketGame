#include<stdio.h>
#include<graphics.h>
int main()
{
	int gd=DETECT,gm,left=100,right=100,top=200,bottom=200,x=300,y=150,r=50;
	initgraph(&gd,&gm,"C:\User\Dell\Desktop\pendrive\graphics.h");
	rectangle(left,right,top,bottom);
	closegraph();
	return 0;
}
