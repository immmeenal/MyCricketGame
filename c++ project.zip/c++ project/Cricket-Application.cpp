
#include"game1.h"
using namespace std;
int main()
{
  Game game;
  
  game.welcomeUsers();
  
  game.displayAllPlayers();
  
  game.selectTeamPlayer();
   
  game.showTeamPlayers();
    
  game.toss();
  

  game.startFirstInnings();
  
  game.startSecondInnings();
  
  game.displayMatchSummary();
  cin.ignore(numeric_limits<streamsize>::max(),'n');
	return 0;
}
