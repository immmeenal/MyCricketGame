#include<string>

class Player{
	public:
		Player();//default constructor
		std::string name;
		int id;//unique id of player
		
		int runsScored;
		int ballsPlayed;
		int ballsBowled;
		int runsGiven;
		int wicketsTaken;//in innings
	
};
