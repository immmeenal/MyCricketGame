#include<iostream>
#include<string>
using namespace std;
class Bank{
	private:
		string banknm;
	public:
		void create()
		{
			cout<<"\n Enter your bank name: ";
			cin>>banknm;
		}
		void display()
		{
			cout<<"\n Bank name: "<<banknm;
		}
};
class Account : private Bank{
	private:
		string accholdnm;
		int accid;
		int panno;
		int adharno;
	public:
	   void input()
	   {
	   	    create();
	   	    cout<<"\n Enter account holder name: ";
	   	    cin>>accholdnm;
	   	    cout<<"\n Enter account id: ";
	   	    cin>>accid;
	   	    cout<<"\n Enter pancard number: ";
	   	    cin>>panno;
	   	    cout<<"\n Enter adhar card number: ";
	   	    cin>>adharno;
		} 
		void output()
		{
			display();
			cout<<"\n account  holder name: "<<accholdnm;
	   	    cout<<"\n account id: "<<accid;
	   	    cout<<"\n pancard number: "<<panno;
	   	    cout<<"\n adhar card number: "<<adharno;
		}	
};
class Currentaccount : private Account {
	public:
		int accbal;
		int overdraft;
		Currentaccount()
		{
			this->accbal=0;
		}
		void create1()
		{
			input();
			cout<<"\n Enter account balance: ";
	   	    cin>>accbal;
			cout<<"\n Enter amount for overdraft: ";
			cin>>overdraft;
			accbal = accbal + overdraft;
		}
		void show()
		{
			output();
			cout<<"\n account balance: "<<accbal;
			cout<<"\n amount for overdraft: "<<overdraft;
			cout<<"\n -----------------------------------";
			cout<<"\n transiction processing......";
			cout<<"\n -----------------------------------";
			cout<<"\n transiction successful\n";
			cout<<"\n Account balance: "<<accbal;
		}
};
class Savingaccount : private Account{
	public:
      	int withdrawal;
		int deposite;
		int accBal;
		int ch;
		void createShow()
		{
		 input();
		 cout<<"\n Enter your account balance: ";
		 cin>>accBal;
		 cout<<"\n1. for withdrawal...\n\n2. for deposite...";
		 cout<<"\n Enter your choice: ";
		 cin>>ch;
		 switch(ch)
		 {
		 	case 1:
		 		cout<<"\n Enter amount for withdrawal: ";
		 		cin>>withdrawal;
		 		cout<<"\n=========================================================\n\n";
		 		cout<<"\n=========================================================\n";
	            cout<<"......................Account Details..................\n";
	       	    cout<<"=========================================================\n";
				output();
		 		cout<<"\n Withdrawal amount:  "<<withdrawal;
		 		accBal=accBal-withdrawal;
		 		cout<<"\n Now your account balance is:  "<<accBal;
		 		break;
		 	case 2:
		 		cout<<"\n Enter amount for deposite: ";
		 		cin>>deposite;
		 		cout<<"\n=========================================================\n\n";
		 		cout<<"\n=========================================================\n";
	            cout<<"......................Account Details..................\n";
	       	    cout<<"=========================================================\n";

		 		output();
		 		cout<<"\n Deposite amount:  "<<deposite;
		 		accBal=accBal+deposite;
			 	cout<<"\n Now your account balance is: "<<accBal;
		 		break;
		 	default:
		 		cout<<"\nInvalid Input...plz try again-";
		 		createShow();
		 		break;
		 		
		 }
		 	}		
};
class Recurringaccount : Account{
	public:
	  int termOfAcc;
	  int monthDeposite;
	  double rateofInterest;
	  void input2()	{
	  	input();
	  	cout<<"\n Enter Term of account in months: ";
	  	cin>>termOfAcc;
	  	cout<<"\n Enter monthly amount to be deposited: ";
	  	cin>>monthDeposite;
	  }
	  void display4(){
	  	output();
	  	cout<<"\n Term of account :  "<<termOfAcc;
	  	cout<<"\n Monthly ammount to be deposited:  "<<monthDeposite; 
		cout<<"\n\n ............Know your total premium amount...........\n"; 
		rateofInterest=termOfAcc*monthDeposite;
		cout<<"\n total premium amount: "<<rateofInterest;
	  }
};
int main()
{
	int ch;
	do{
	cout<<"\n ........................WELCOME........................\n";
	cout<<"\n 1. Current Account \n 2. Saving Account \n 3. Rcurring Account \n";
	cout<<"\n Enter your choice.....   ";
	cin>>ch;
	Currentaccount c;
	Savingaccount s;
	Recurringaccount r;
	cout<<"\n=========================================================\n";
	abc:
	switch(ch)
	{
		case 1:
			Currentaccount();
	        c.create1();
	        cout<<"\n=========================================================\n\n";
			cout<<"\n=========================================================\n";
	        cout<<"......................Account Details..................\n";
	       	cout<<"=========================================================\n";
	       	c.show();
			break;
		case 2:
        	s.createShow();		
		    break;
		case 3:
		    r.input2();
		    cout<<"\n=========================================================\n\n";
		    cout<<"\n=========================================================\n";
	        cout<<"......................Account Details..................\n";
	       	cout<<"=========================================================\n";

		    r.display4();
		    break;
		default:
		 		cout<<"\nInvalid Input...plz try again-";
                goto abc;
		 		break;			
	}		
    cout<<"\n=========================================================\n\n";
    cout<<"\n.........................THANK YOU.......................\n\n";
    cout<<"\n Do you want to continue press 1: ";
    cin>>ch;
    }while(ch==1);
	return 0;
}
