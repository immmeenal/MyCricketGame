#include "player1.h"    //<string>
Player::Player()//default constructor definition
{
		 runsScored = 0;
		 ballsPlayed = 0;
		 ballsBowled = 0;
		 runsGiven = 0;
		 wicketsTaken = 0;
	
}
