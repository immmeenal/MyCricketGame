#include"team1.h"    //"player.h" ,<string> ,<vector>

Team::Team(){//defining default constructor
	
      totalRunsScored=0;
	  wicketLost=0;
	  totalBallsBowled=0;
}
