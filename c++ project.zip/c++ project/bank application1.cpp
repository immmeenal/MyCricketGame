#include<iostream>
#include<string>
using namespace std;
class Bank{
	public:
		string bankName;
		

		/*Bank()
		{
			this->bankName=bankName;
		}*/
	    void accept()
		{
			cout<<"\n Enter your Bank Name: ";
			cin>>bankName;
			
	    }	
	    void display()
	    {
	    	cout<<"\n Your bank name is:  "<<bankName;
	    	
		}
};
class Account : public Bank{
	public:
		string accName;
		int adharNo;
		int panNo;
		int accId;
		int accBal;
		
    /*	Account()
    	{
           this->accName=accName;
		   this->adharNo=adharNo;
		   this->panNo=panNo;
		   this->accId=accId;
	       this->accBal=accBal;
		}*/
    	void create()
    	{
    		Bank::accept();
    		cout<<"\n Enter your account number: ";
    		cin>>accName;
    		cout<<"\n Enter Adhar card Number: ";
    		cin>>adharNo;
    		cout<<"\n Enter pancard Number: ";
    		cin>>panNo;
    		cout<<"\n Please enter your account id: ";
    		cin>>accId;
    		cout<<"\n Enter your account balance: ";
    		cin>>accBal;
		}
		void output()
		{
			Bank::display();
			cout<<"\n Account number:  "<< accName;
			cout<<"\n Adhar card Number:  "<< adharNo;
			cout<<"\n Pancard Number:  "<< panNo;
			cout<<"\n Account Id:  "<< accId;
			cout<<"\n Account Balance:  "<< accBal;
		}
};
int main()
{
	cout<<"\n =======================================\n";
	Account a;
	a.accept();
	a.output();
	cout<<"\n =======================================\n\n";
	return 0;
}
