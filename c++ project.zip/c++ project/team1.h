#include <vector>//same as array but can change its size
#include "player1.h"    //<string>

class Team{
	public:
      Team();
	  std::string name;
	  int totalRunsScored;
	  int wicketLost;
	  int totalBallsBowled;
	  //int totalBallsPlayed; while batting
	  std::vector <Player> player;
	
};
