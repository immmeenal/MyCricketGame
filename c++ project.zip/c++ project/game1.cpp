#include"game1.h"
using namespace std;
/*#include <iostream> //handle i/o stream
#include <cstdlib> // rand(),srand()
#include <ctime> // time()
#include <limits> //
//#include <string> //
//#include <vector> // vector are similar to array ,but cant change its size
#include "team.h" //<vector> ,"player.h" ,<string> */
Game::Game()
{
	isFirstInning=false;   // default value
	teamA.name="Team-A";
	teamB.name="Team-B";
	playersPerTeam=4;
	maxBalls=6;
    totalPlayers=11;
    players[0]="Virat";
    players[1]="Rahul";
    players[2]="Dhoni";
    players[3]="Malinga";
    players[4]="Jadeja";
    players[5]="Pant";
    players[6]="Dravid";
    players[7]="Pandey";
    players[8]="Sharma";
    players[9]="Bumrah";
    players[10]="Hardik";
}

void Game::welcomeUsers()
{
  cout<<"\t\t|===========================================================|\n";
  cout<<"\t\t|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t|             WELCOME TO THE VIRTUAL CRICKET GAME           |\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t|- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -|\n";
  cout<<"\t\t|===========================================================|\n\n";
  
  cout<<"\n\n";
  
  cout<<"\t\t|*** *** *** *** *** *** *** *** *** *** *** *** *** *** ***|\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t|-----------------   // GAME INSTRUCTIONS //    ------------|\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t| 1)Create two teams (Team-A and Team-B with 4 players      |\n";
  cout<<"\t\t|    each from a given pool of 11 players.                  |\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t| 2)Lead the toss and decide the choice of play.            |\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t| 3)Each innings will be of 6 balls.                        |\n";
  cout<<"\t\t|                                                           |\n";
  cout<<"\t\t|*** *** *** *** *** *** *** *** *** *** *** *** *** *** ***|\n\n";  		
}

void Game::displayAllPlayers()
{
  cout<<"\t\tPress ENTER to continue: ";
  getchar();
  cout<<"\n\n\t\t|------------------------------------------|\n";
  cout<<"\t\t*** *** ***   POOL OF PLAYERS   *** *** ***\n";
  cout<<"\t\t|------------------------------------------|\n";
  cout<<"\n\n";
  int i;
  for(i=0;i<11;i++)
  {
   	cout<<"\t\t" << "\t\t [ " << i+1 << " ]  " << players[i];
   	cout<< endl << endl;
  }	
} 
int Game::takeIntegerValue()
{
	int n;
	
	//cin>>n;
	
	while(!(cin>>n)){
		
		cin.clear();//clear error flags
		//while(getchar()!='\n')-to clear the input buffer memory
		cin.ignore(numeric_limits<streamsize>::max(),'\n');
		//to clear input buffer memory in cpp....
		cout<<"\t\tInvalid input! Please try again with valid input ";
	}
    
    return n;
}

bool Game::validateSelectedPlayer(int index)
{
	int n;
	vector<Player> players;
	
	players=teamA.player;
	n=players.size();
	for(int i=0;i<n;i++)
	{
		if(players[i].id==index){
			return false;
		}
	}
	
	players=teamB.player;
	n=players.size();
	for(int i=0;i<n;i++)
	{
		if(players[i].id==index){
			return false;
		}
	}
	return true;
}
void Game::selectTeamPlayer()
{
	cout<<"\n\n\t\tPress ENTER to continue: ";
    getchar();
    
    cout<<endl<<endl;
    cout<<"\t\t---------------------------------------\n\n";
    cout<<"\t\t.......Create Team-A and Team-B........\n\n";
    cout<<"\t\t*** *** *** *** *** *** *** *** *** ***\n\n";
    
    for(int i=0;i<playersPerTeam;i++)
    {
    	
    	//select players for team A
    teamASelection:
    	cout<<"\n\t\tSelect player " << i+1 << " for Team-A : ";
    	 int playerAIndexValue=takeIntegerValue();
    	 
    	if(playerAIndexValue < 1 || playerAIndexValue > 11)
    	 {
    	 	cout<<"\n\t\tPlease select players from given pool of players: ";
            
			goto teamASelection; 		 
		 }
		
		else if(!validateSelectedPlayer(playerAIndexValue))
		{
		 	cout<<"\n\n\t\tPlayer has been selected already. Please select other player \n\n";
		    goto teamASelection;
		 } 
		 
		 else{
		 	 Player teamAPlayer;//player obj
    	 teamAPlayer.id=playerAIndexValue;//unique id of player
    	 teamAPlayer.name=players[playerAIndexValue];//strings player array
    	 
    	 teamA.player.push_back(teamAPlayer);
    	 
		 }
    	
    //	select players for team B
    	teamBSelection:
    	cout<<"\n\t\tSelect player " << i+1 << " for Team-B : ";
    	 int playerBIndexValue=takeIntegerValue();
    	 
    	  if(playerBIndexValue < 1 || playerBIndexValue > 11)
    	 {
    	 	cout<<"\n\t\tPlease select players from given pool of players: ";
		 
		    goto teamBSelection; 
		 }
		 
		 else if(!validateSelectedPlayer(playerBIndexValue))
		{
		 	cout<<"\n\n\t\tPlayer has been selected already. Please select other player \n\n";
		    goto teamBSelection;
		 } 
		 
		 else{
		 	Player teamBPlayer;
    	 teamBPlayer.id=playerBIndexValue;
    	 teamBPlayer.name=players[playerBIndexValue];
    	 
    	 teamB.player.push_back(teamBPlayer);
		 }
    	 
	}
}

void Game::showTeamPlayers()
{
	vector<Player> teamAplayers= teamA.player;
	
	vector<Player> teamBplayers= teamB.player;
	cout<<"\n\n";
	
	cout <<"\n==================================\t==================================\n\n";
    cout <<":            Team-A              : \t :             Team-B          :\n\n";
    cout <<"==================================\t==================================\n\n";


    for(int i=0;i<playersPerTeam;i++)
    {
    	cout<<":\t" << " [ " << teamAplayers[i].id << " ] " << teamAplayers[i].name <<"\t\t:"
            <<"\t:\t" << " [ " << teamBplayers[i].id << " ] " << teamBplayers[i].name <<"\t\t:\n";
	}
	   cout <<"==================================\t==================================\n\n";
     
} 

void Game:: toss()
{
  cout<<"\n\n\t\tPress ENTER to toss: ";
  getchar();
   
  cout<<endl;
  cout<<"\t\t -------------------------------------\n\n";
  cout<<"\t\t!!! !!! !!! !!! LET'S TOSS !!! !!! !!! !!!\n\n";
  cout<<"\t\t -------------------------------------\n\n";
  
  cout<<endl;
  cout<<"\t\tTossing the coin.......\n\n";
  
  srand(time(NULL));
  int randomValue =rand() % 2;  //0 or 1
  
  switch(randomValue){
  	case 0:
  		cout<< "\t\tTeam-A won the toss!!!\n\n";
  		tossChoice(teamA);
  		break;
  	case 1:
  		cout<< "\t\tTeam-B won the toss!!!\n\n";
  		tossChoice(teamB);
  		break;
  }  
}

void Game::tossChoice(Team tossWinnerTeam)
{
  cout<<" \t\t Enter 1 to bat or 2 to bowl first. \n\n"<<"\t\t1.Bat \n\n"<<"\t\t2.Bowl\n\n\t\t";
  
  int choice= takeIntegerValue();
  
   switch(choice){
   	case 1:
   		cout<<"\n\t\t"<<tossWinnerTeam.name <<" won the toss and elected to bat first.\n\n";
   	    if(tossWinnerTeam.name.compare("Team-A")==0)    // if Team-A is winner
	      {
	   	    battingTeam=&teamA;
	   	    bowlingTeam=&teamB;
	      }
	      else   // else Team-B is winner
	      {
	   	    battingTeam=&teamB;
	   	    bowlingTeam=&teamA;
	      }
	   	break;
   	case 2:
   		cout<<"\n\t\t"<< tossWinnerTeam.name << " won the toss and elected to bawl first.\n\n";
   	  if(tossWinnerTeam.name.compare("Team-A")==0)//if Team-A is winner
	       {
	   	    battingTeam=&teamA;
	   	    bowlingTeam=&teamB;
	      }
	      else   // else Team-B is winner
	      {
	   	    battingTeam=&teamB;
	   	    bowlingTeam=&teamA;
	      }
		
	  break;
	default:
		cout<<"\n\t\tInvalid input please try again...\n\n";
		tossChoice(tossWinnerTeam);
	   break;   	
   		
   }	
}

void Game::startFirstInnings()
{
	cout<<"\t\t ||| FIRST INNINGS STARTS |||\n\n";
	isFirstInning=true;
	initializePlayers();
	playInnings();
}

void Game::initializePlayers()
{
 //choose batsman and bawler: Initialize *batsMan and *bawler	
  batsMan=&battingTeam->player[0];
  bowler=&bowlingTeam->player[0];
  
  cout<<"\t\t" << battingTeam->name <<" - "<<batsMan->name<<" is batting \n";	
  cout<<"\t\t" << bowlingTeam->name <<" - "<<bowler->name<<" is bawling \n\n";
}

void Game::playInnings()
{
	for(int i=0;i<maxBalls;i++)
	{
		cout<< "\t\t\nPress ENTER to bawl.....\n\n";
		getchar();
		cout<<"\t\tBawling.....\n";
		bat();
		showGameScoredcard();
		if(!validateInningsScore())
		{
			break;
		}
	}
}

void Game::bat()
{
	srand(time(NULL));
	int runsScored = rand() % 7;    //  0,1,2,3,4,5 or 6
	
	//Update batting team and batsman score
	batsMan->runsScored = batsMan->runsScored + runsScored;
	battingTeam->totalRunsScored = battingTeam->totalRunsScored + runsScored;
	batsMan->ballsPlayed = batsMan->ballsPlayed + 1;
	
	//Update bawling team and bawler score
	bowler->ballsBowled = bowler->ballsBowled + 1;
	bowlingTeam->totalBallsBowled = bowlingTeam->totalBallsBowled + 1;
	bowler->runsGiven =	bowler->runsGiven + runsScored;
	
	if(runsScored!=0)   // if runsScored = 1,2,3,4,5 or 6
	{
	cout<<"\n\t\t"<< bowler->name << "  to  " << batsMan->name << "  " << runsScored << "  runs!\n\n"; 
    }
    else {  // else runsScored = 0 and the batsman is OUT!
    	cout<<"\n\t\t" << bowler->name << " to " << batsMan->name << " OUT!\n\n";
    	battingTeam->wicketLost = battingTeam->wicketLost + 1;
    	bowler->wicketsTaken = bowler->wicketsTaken + 1;
    	int nextPlayerIndex = battingTeam->wicketLost;
    	batsMan = &battingTeam->player[nextPlayerIndex];
    	
	}
}

bool Game::validateInningsScore()
{
	if(isFirstInning)
	{
		if(battingTeam->wicketLost == playersPerTeam || bowlingTeam->totalBallsBowled == maxBalls){
		
		   cout<<"\t\t   ||| FIRST INNINGS ENDS ||| \n\n";
		   
		   cout<< "\t\t" << battingTeam->name << " " << battingTeam->totalRunsScored << " - "
		   <<battingTeam->wicketLost << " ( " << bowlingTeam->totalBallsBowled << " ) \n"; 
		   
		   cout<< "\t\t" << bowlingTeam->name << " needs " << battingTeam->totalRunsScored + 1
		   <<" runs to win the match \n\n";	 	
			return false;
		}
	}
	else  // Else 2nd innings
	{
           if(battingTeam->totalRunsScored > bowlingTeam->totalRunsScored  )
		   {
		   	  cout<< " \t\t " << battingTeam->name << " WON THE MATCH !!! \n\n";
              	return false;
		   }
		   else if(battingTeam->wicketLost == playersPerTeam || bowlingTeam->totalBallsBowled == maxBalls)
		   {
		   	    if(battingTeam->totalRunsScored > bowlingTeam->totalRunsScored)
		   	    {
		   	       	cout<< " \t\t " << battingTeam->name << " WON THE MATCH !!! \n\n";
                    	return false;
				}
				
				else if(battingTeam->totalRunsScored < bowlingTeam->totalRunsScored)
				{
					cout<< " \t\t " << bowlingTeam->name << " WON THE MATCH !!! \n\n";
				       	return false;
				}
				else
				{
					cout << "\t\t Match Draw \n\n";
						return false;
				}
		   }		
	}
	return true;
}

void  Game::showGameScoredcard()
{
	cout<<"\n\t\t -------------------------------------------------------------------------------------\n";
	cout<<"\t\t\t" << battingTeam->name << " " << battingTeam->totalRunsScored << " - " 
	<< battingTeam->wicketLost << " ( " << bowlingTeam->totalBallsBowled << " )   |   "
	<< batsMan->name << " " << batsMan->runsScored << " ( " << batsMan->ballsPlayed << " )  "
	<< bowler->name << " " << bowler->ballsBowled << " - " << bowler->runsGiven << " - " << bowler->wicketsTaken <<" \n";
    cout<<"\t\t -------------------------------------------------------------------------------------\n\n";

}

void Game::startSecondInnings()
{
    cout<<"\n\t\t ||| SECOND INNINGS STARTS |||\n\n";
    
	swap(&teamA,&teamB);
	isFirstInning=false;
	initializePlayers();
	
	playInnings();
		
}
void Game::swap(Team *battingTeam, Team *bowlingTeam )
{
   	Team swap = *battingTeam;
   	*battingTeam = *bowlingTeam;
   	*bowlingTeam = swap;
	
}
void Game::displayMatchSummary()
{
	cout<<"\n\n\t\t\t |||  MATCH ENDS  |||\n\n";
	
	 
	 vector<Player> teamAplayers= teamA.player;
	
	 vector<Player> teamBplayers= teamB.player;
	
	
	cout<<" \t\t\t " << teamA.name << " " << teamA.totalRunsScored << " - "
	 << teamA.wicketLost <<" ( " << teamA.totalBallsBowled << " ) \n\n";
	
	    cout<<"\t\t================================================\n";
	    cout<<"\t\t|  PLAYER \t  BATTING \t BAWLING\t|\n";
	
	for(int i=0;i<playersPerTeam;i++)
	{ 
	    cout<<"\t\t|---------------------------------------------\t|\n";
		cout<< "\t\t|  [ " << i+1 << " ] " << "  " << teamAplayers[i].name 
		<<"\t" << teamAplayers[i].runsScored << "(" << teamAplayers[i].ballsPlayed <<")"
		<<"\t" << teamAplayers[i].ballsBowled <<" - " << teamAplayers[i].runsGiven << " - " << teamAplayers[i].wicketsTaken
		<<"\t|\n";
	}
        cout<<"\t\t================================================\n\n";
		
	
	cout<<" \t\t\t " << teamB.name << " " << teamB.totalRunsScored << " - "
	 << teamB.wicketLost <<" ( " << teamB.totalBallsBowled << " ) \n\n";
	 	
     cout<<"\t\t================================================\n";
	    cout<<"\t\t|  PLAYER \t   BATTING \t BAWLING\t|\n";
	
	for(int i=0;i<playersPerTeam;i++)
	{ 
	    cout<<"\t\t|---------------------------------------------\t|\n";
		cout<< "\t\t|  [ " << i+1 << " ] " << "  " << teamBplayers[i].name 
		<<" \t " << teamBplayers[i].runsScored << "(" << teamBplayers[i].ballsPlayed <<")"
		<<"\t" << teamBplayers[i].ballsBowled <<" - " << teamBplayers[i].runsGiven << " - " << teamAplayers[i].wicketsTaken
		<<"\t|\n";
	}
        cout<<"\t\t================================================\n";			
}
