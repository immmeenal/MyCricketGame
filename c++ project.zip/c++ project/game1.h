#include<iostream>//handle iostream
#include<cstdlib>//standard library (rand(),srand())
#include<ctime>//time()
#include<limits>//limits()
#include "team1.h"   // "player1.h" , <string> ,<vector>

class Game{
	public:
		Game();
	    int playersPerTeam;
		int maxBalls;
		int totalPlayers;
		
		bool isFirstInning;
		Team teamA,teamB;
		std::string players[11];
		Team *battingTeam,*bowlingTeam;
		Player *batsMan,*bowler;
	  
	    void welcomeUsers();
	    void displayAllPlayers();
	    int takeIntegerValue();
	    void selectTeamPlayer();
	    bool validateSelectedPlayer(int);
	    void showTeamPlayers();
	    void toss();
	    void tossChoice(Team);//team obj (winning team)
	    void startFirstInnings();
	    void initializePlayers();
	    void playInnings();
	    void bat();
	    bool validateInningsScore();
	    void showGameScoredcard();
	    void startSecondInnings();
	    void displayMatchSummary();
	    void swap(Team *,Team *);
};
